'''

La complessità è 
$\Theta(|stringa1| * |stringa1|) \rightarrow \Theta(|città_mamma| * |città_papà|)$

'''


import numpy as np


# Ricorsivo (vedere iterativo)
'''
def solve(s1, s2):

	def DP(i,j):
		if(i >= len(s1)):
			return 0, []
		if(j >= len(s2)):
			return 0, [x for x in range(i,len(s1))]

		if(s1[i] == s2[j]):
			return DP(i+1,j+1)

		choices = [DP(i+1,j), DP(i,j+1)]
		choice = np.argmin([x[0] for x in choices])

		rm = [] if choice == 1 else [i]

		return 1 + choices[choice][0] , rm + choices[choice][1]

	_, to_remove = DP(0,0)
	return len(s1) - len(to_remove)
'''

# Iterativo
def solve(s1 : str, s2 : str) -> np.array:
	l1 = len(s1)
	l2 = len(s2)
	mat = np.zeros(dtype=int,shape=(l1+1,l2+1))

	for i in range(l1):
		for j in range(l2):
			if(s1[i] == s2[j]):
				mat[i+1,j+1] = mat[i,j] + 1
			else:
				mat[i+1,j+1] = max(mat[i,j+1], mat[i+1,j])

	return mat[-1,-1]

def main():
	i=1
	while(True):
		str1 = input()
		if(str1 == '#'):
			break
		str2 = input()

		print(f"Caso #{i}: numero massimo = {solve(str1,str2)}")
		i+=1


if __name__ == '__main__':
	main()