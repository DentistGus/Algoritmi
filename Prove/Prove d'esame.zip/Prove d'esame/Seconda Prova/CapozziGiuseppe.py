# -*- coding: utf-8 -*-
"""
La complessità dell'algoritmo è O(n^2) dato che l'ho implementato utilizzando la programmazione dinamica in maniera bottom-up a partire da una descrizione del problema in cui il numero dei sottoproblemi era pari proprio a O(n^2) e il tempo per sottoproblema pari a O(1)
"""

 
 






def vacanza(memo,madre,padre,lenMadre,lenPadre):
    for i in range(0,lenMadre): 
        for j in range(0,lenPadre):
            if madre[i] == padre[j]: 
               memo[i+1][j+1] = memo[i][j] + 1 
            else: 
              memo[i + 1][j + 1] = max(memo[i][j + 1], memo[i + 1][j]) 

def main():
    try:
        madre = input() 
        iterazione = 1 
     
     
        while(madre != "#"): 
            padre = input() 
            lenMadre = len(madre) 
            lenPadre = len(padre) 
            memo = [[0]*101]*101 
            vacanza(memo,madre,padre,lenMadre,lenPadre)
        
    
     
            print("Case#",iterazione,"numero massimo =",memo[lenMadre][lenPadre]) 
            iterazione += 1 
            madre = input()
    except EOFError:
        return
    
    
main()
  
    

    

