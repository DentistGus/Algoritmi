#include<iostream>
#include <string>
#include<vector>
using namespace std;

//Sottoproblemi: Sono le sue stringhe s1[i:] s2[j:] #numero_sottoproblemi= O(size(s1)*size(s2))

//Guessing: Se le città sono uguali allora posso visitare la città altrimenti devo scegliere se proseguire
//            sulla lista della madre o sulla lista del padre( su s1  o s2, quindi se incrementare i o j)
//             #numero_scelte=Theta(1)

//Ricorrenza:
//  Se sono uguali dp[i][j]=1+dp[i+1][j+1] , ossia incrementa entrambe le città e visitala(+1)
//  Altrimenti se sono divese: dp[i][j]=max[ dp[i+1][j],dp[i][j+1] ] ossia controlla quale delle due mi conviene esplorare

//Ordine topologico: Stesso ragionamento dell'edit distance, ogni punto della matrice i e j dipende o
//  dal vicino destro(j+1) oppure da quello che sta sotto i+1 ossia:
//            (i,j)<-(i,j+1)
//              ^
//              |
//            (i+1,j)

//Ricostruzione:dp[0][0] contiene la soluzione, no extra time

//Tempo= Numero sottoproblemi per tempo sottoproblema=
// O(size(s1)*size(s2))*1=O(size(s1)*size(s2))  , chiamando size(s1)=n ed size(s2)=m abbiamo O(nxm)
unsigned int city_travel(string s1,string s2,vector<vector<int> > &dp,unsigned int i,unsigned int j){
  if(i>=s1.size() || j>=s2.size()) //Sono giunto alla fine, ritorna 0
    return 0;
  if(dp[i][j]!=-1)
    return dp[i][j];
  if(s1[i]==s2[j]) //Le stringhe sono uguali, posso visitare questa città
    dp[i][j]=1+city_travel(s1,s2,dp,i+1,j+1); // la città visitata più le rimanenti
  else //Altrimenti
    dp[i][j]=max(city_travel(s1,s2,dp,i+1,j),city_travel(s1,s2,dp,i,j+1)); //Scelta tra quale due città tralasciare
  return dp[i][j]; //Ritorna la soluzionne
}
int main(){
  string end="#";
  string s1, s2;
  cin>>s1;
  while(s1!=end){
    cin>>s2;
    vector<vector<int > >dp(s1.size(),vector<int>(s2.size(),-1));
    cout<<"numero massimo = "<<city_travel(s1,s2,dp,0,0)<<endl;
    cin>>s1;
  }
  return 0;
}
