#include<bits/stdc++.h>
using namespace std;

/*  Nome: 		Impero Vittorio
    Cognome:	Eboli
    Matricola:	M63001310 
*/

//Codice:
int main(){

    string a, b;
    int t = 0;
    while(true){

            t++;
           cin>>a;

            if(a=="#") break;

            cin>>b;

            int m, n;

            m=a.length();
            n=b.length();

            int i, j;

            int dp[m+1][n+1];

            for(i=0; i<m+1; i++) dp[i][0]=0;

            for(j=0; j<n+1; j++) dp[0][j]=0;

            for(i=1; i<m+1; i++)
                     for(j=1; j<n+1; j++)
                              if(a[i-1] == b[j-1])
                                  dp[i][j] = dp[i-1][j-1] + 1;
                              else
                                  dp[i][j] = max(dp[i-1][j], dp[i][j-1]);

            cout<<"Caso #"<<t<<": numero massimo = "<<dp[m][n]<<endl;

    }

}

/*La complessit� dell'algoritmo risulta essere Theta(n * m),
a causa dei due cicli for innestati che contengono la ricorrenza.
A questa andrebbero sommati i contributi del calcolo della lunghezza
delle stringhe in input (con la funzione std::iostream::length()) 
e quelli per l'inizializzazione della prima colonna e della prima 
riga a 0 (che tendono ad essere assorbiti dai successivi for per 
la ricorrenza). Nel caso in cui n=m, la complessit� risuler� essere O(n^2) */
