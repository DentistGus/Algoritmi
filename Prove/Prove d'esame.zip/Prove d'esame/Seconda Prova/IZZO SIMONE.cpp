#include <bits/stdc++.h>
using namespace std;
//madre= parigi, madrid, lisbona e londra
//padre=parigi,lisbona,londra e madrid   (londra-parigi-lisbonoa-madrid-->sol: parigi-lisbona e parigi-madrid)
//soluzione: parigi-lisbona-londra
//ogni città con un char  al max ho unn vett di 63
#define max 63
int dp[max][max];
char mamma[max];
char papa[max];//r1 e r2
int k=0;

     int Max(int a,int b,int c){
     return a > b ? (a > c ? a : c) : (b > c ? b : c );
 }
 

int main() {
    int ct;
    cin>>ct;
    while(ct--){
        
        k++;
    int Ncitta;
    cin>>Ncitta;

	for(int i = 0 ; i<Ncitta ; i++){
	    cin>>mamma[i];
	}
	for(int j = 0 ; j<Ncitta ; j++){
	    cin>>papa[j];
	}
	
    int n1=strlen(mamma);
	int n2=strlen(papa);
	dp[n1][n2]={0};
	memset(dp,0,sizeof(dp));
	
	bool flag=false;
	
	for(int i = 0 ; i<n1;i++){
	    if(flag || mamma[i]==papa[0]){
	        flag=true;
	        dp[i][0]=1;
	    }
	}
    
    flag=false;
	for(int j = 0 ; j<n2 ; j++){
	    if(flag|| mamma[0]==papa[j]){
	        flag=true;
	        dp[0][j]=1;
	    }
	}
	
	//funzione risolvi
	for(int i = 1 ; i < n1+1 ; i++){
	    for(int j = 1 ; j < n2+1 ; j++){
	        if(mamma[i]==papa[j]){
	            dp[i][j]=dp[i-1][j-1]+1;
	        }
	        dp[i][j]=Max(dp[i][j],dp[i-1][j],dp[i][j-1]);
	    }
	}

        
	cout<<"il caso di test: "<<k<<" dice che puoi visitare "<< dp[n1-1][n2-1] << " citta "<<endl;
}
	
	
	
	return 0;
}

//La complessità e' n quadro 
L'input che inserisco è il seguente.
2
4
abcd
acdb
4
abcd
dacb
