def trovaMaxSub(s1,s2):
    l1 = len(s1)
    l2 = len(s2)
  
    memo = [[0]*(l2 + 1) for i in range(l1 + 1)]
      #creo la tabella per salvare i risultati con list comprhe
    for i in range(0, l1 + 1): #itero sulla prima stringa
        for j in range(0, l2 + 1): #itero sulla seconda
            #cosi da confrontare tutti i caratteri e trovare le sequenze
            if i == 0 or j == 0 : #se sto all'inizio di una delle due stringhe
                memo[i][j] = 0
            elif s1[i-1] == s2[j-1]:#se i due caratteri sono uguali(in posizioni non omologhe anche)
                memo[i][j] = memo[i-1][j-1]+1
            else:
                memo[i][j] = max(memo[i-1][j], memo[i][j-1])
    return memo[l1][l2]
#L[m,n] è il numero di citta max che si possono visitare dati i due ordini
#considerando fino alla citta m di s1, e la citta n di s2
#la COMPLESSITA è l1*l2 dato che utiliziamo due cicli for(innestati)

def main():
    sequenza = list()
    s = str(input())
    while s!= "#":
        sequenza.append(s)
        s = str(input())
    N = len(sequenza)
    
    if N%2 == 1:
        print("Numero coppie dispari")
        return 0
    c = N//2
    
    for i in range(0, c+1,2):
        s1 = sequenza[i]
        s2 = sequenza[i+1]
        print(trovaMaxSub(s1,s2))

if __name__ == '__main__':
    main()




