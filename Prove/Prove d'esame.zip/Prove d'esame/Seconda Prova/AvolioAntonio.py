# cook your dish here
def main():
    case=1

    while(True):
        travel_1 = input()
        if travel_1 == "#": # Se incontra "#" deve fermarsi
            break
        travel_2 = input()
        
        n = len(travel_1) # Salvo la lunghezza per non doverla calcolare
        m = len(travel_2) # ogni volta tramite la funzione len()
        
        # Creo una matrice vuota di dimensioni maggiorate di 1 poichè
        # i confronti finiscono usano anche [i+1,j+1]
        matrix = [ [ 0 for _ in range(n+1) ] for _ in range(m+1) ]
        # Gli underscore si utilizzano per dichiarare variabili "superflue"
        for i in range(n):
            for j in range(m):
                #Se le città sono uguali vengono considerate come percorso praticabile
                if(travel_1[i] == travel_2[j]): 
                    matrix[i+1][j+1] = matrix[i][j]+1
                # Altrimenti vede il massimo dei percorsi praticati nei "passaggi" vicini
                else:
                    matrix[i+1][j+1] = max(matrix[i+1][j],matrix[i][j+1])

        print("Caso {}: numero massimo = {}".format(case,matrix[n][m]))
        case+=1
        

if __name__ == "__main__":
    main()

# La complessità dell'algoritmo è : O(n*m) più trascurabili costanti,
# come il calcolo delle lunghezze delle due stringhe, in quanto sono
# presenti i due cicli principali che iterano completamente su
# entrambe le stringhe