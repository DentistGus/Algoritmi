#Raffaele Carillo M63001321
#Indicando con n1 la lunghezza della prima sequenza di città e con n2 la lunghezza della seconda sequenza di città le complessità per ogni coppia di sequenze sono:
#Θ(n1*n2) temporale 
#Θ(n1*n2) spaziale




d = 1
while True:
    seq_1 = input("Inserire prima sequenza: ")
    seq_2 = input("Inserire seconda sequenza: ")
    if len(seq_1) > 0:
        if seq_1[0] == "#":
            print("exit") #exit()
            break
    
    if len(seq_2) == 0 or len(seq_1) == 0:
        print("Sequenza non valida, numero città = 0.")
        continue
    

    if len(seq_1) > 100 or len(seq_2) > 100:
        print("Numero città eccessivo caso " + str(d)+ " da reinserire.")
        continue

    if not seq_1.isalnum() or not seq_2.isalnum():
        print("Sequenza non alfanumerica. Caso "+ str(d) + " da reinserire.")
        continue

    table = []
    for i in range(0,len(seq_1)+1):
        table.append([0]*(len(seq_2)+1))

    for i in range(1,len(seq_1)+1):
        for j in range(1,len(seq_2)+1):
            if seq_1[i-1] == seq_2[j-1]:
                table[i][j] = table[i-1][j-1] +1
            else:
                table[i][j] = max(table[i-1][j], table[i][j-1])
    result = table[len(seq_1)][len(seq_2)]
    print("Caso: #"+ str(d) + " numero massimo " + str(result)) 

    d += 1

