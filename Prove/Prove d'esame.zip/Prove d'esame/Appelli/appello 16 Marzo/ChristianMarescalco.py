
#complessità per ogni test_case è dato dal loop innestato 3 volte della funzione solve:
#essendo un problema simile al prodotto tra matrici (dunque un problema di dp su substrings) 
# il num di sottoproblemi è n^2
# la complessità di ogni sottoproblema è O(n)
#dunque O(n^3)
def solve(elementi,operazioni,minimi,massimi):
    lun = len(elementi)
    for i in range(lun):
        for j in range(lun):
            minimi[i][j] = 100000
            massimi[i][j] = 0
            if(i == j):
                minimi[i][j] = elementi[i]
                massimi[i][j] = elementi[i]
            
    for L in range(2,lun+1):
        for i in range(lun-L+1):
            j = i+L-1
            for k in range(i,j):
                mintmp = 0
                maxtmp = 0
                if(operazioni[k] == '+'):
                    mintmp = minimi[i][k] + minimi[k + 1][j]
                    maxtmp = massimi[i][k] + massimi[k + 1][j]
                elif(operazioni[k] == '*'):
                    mintmp = minimi[i][k] * minimi[k + 1][j]
                    maxtmp = massimi[i][k] * massimi[k + 1][j]
                if (mintmp < minimi[i][j]):
                    minimi[i][j] = mintmp
                if (maxtmp > massimi[i][j]):
                    massimi[i][j] = maxtmp

    return massimi[0][lun-1],minimi[0][lun-1]


test_case = []

while True:
    stringa = input()
    if stringa == '0':
        break
    lista_elem_tot = []
    lista_op = []
    lista_elem = stringa.split('+')
    for lista in lista_elem:
        lista_prod = lista.split('*')
        for elem in lista_prod:
            lista_elem_tot.append(int(elem))
    for s in stringa:
        if(s == '+' or s == '*'):
            lista_op.append(s)
        
    test_case.append([lista_elem_tot,lista_op])

for test in test_case:
    minimi = [[ 0 for i in range(len(test[0]))] for i in range(len(test[0]))]
    massimi = [[ 0 for i in range(len(test[0]))] for i in range(len(test[0]))]
    print(solve(test[0],test[1],minimi,massimi))

#nel caso in cui non funzionasse la procedura di input decommentare
#test1 = [[2, 4, 2, 3, 7],['+', '*', '*', '+']]
#test2 = [[3,14,19,3,10],['*','+','+','*']]
#minimi = [[ 0 for i in range(len(test1[0]))] for i in range(len(test1[0]))]
#massimi = [[ 0 for i in range(len(test1[0]))] for i in range(len(test1[0]))]

#print(solve(test1[0],test1[1],minimi,massimi))


#minimi = [[ 0 for i in range(len(test1[0]))] for i in range(len(test1[0]))]
#massimi = [[ 0 for i in range(len(test1[0]))] for i in range(len(test1[0]))]
#print(solve(test2[0],test2[1],minimi,massimi))