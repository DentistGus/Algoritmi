#include <iostream>
#include <bits/stdc++.h>
using namespace std;

/*
  Nome      :   Impero Vittorio
  Cognome   :   Eboli
  Matricola :   M63001310
  
  Complessita'�:
  
  La Complessita'� del codice risulta tendenzialmente quadratica, 
  a causa del doppio ciclo for, necessario per scorrere l'intera 
  matrice dp[n][n]. All'O(n^2) andrebbero sommate le complessità
  delle funzioni della libreria standard, per calcolare la lunghezza
  dell'oggetto string s (s.length(), la cui complessita'� non e' 
  specificata nella reference), e quella dovuta al calcolo del
  massimo (max(a,b), che richiede un tempo costante per ciascuna 
  iterazione della funzione solve.
  
  */

int solve(string s){
    
   int n = s.length();
   
   if(n > 1000) return -1; //verifica dei costraints
   if(!n) return 0;
   else if(n == 1) return 1;
  
   else{
   
   vector<vector<int> >dp(n,vector<int>(n, 0));
   int j = 0;
 
 //inizializzo dp a 1, nella supposizione che una sequenza di un solo carattere sia sempre palindroma
   for (int i = 0; i < n; i++) dp[i][i] = 1;
 
 /*quando vado a riempire la matrice della dp, ottengo 
 una matrice tutta nulla al di sotto della diagonale principale (in cui restano tutti 1), 
 di cui quindi considero soltanto la meta'� superiore*/
 
    for (int k = 2; k <= n; k++){
        for (int i = 0; i < (n - k + 1); i++){
            
            j = i + k - 1;
            if      (s[i] == s[j] && k == 2) dp[i][j] = 2;                              //gestione dei casi base
            else if (s[i] == s[j])           dp[i][j] = dp[i+1][j-1] + 2;
            else                             dp[i][j] = max(dp[i][j-1], dp[i+1][j]);    //soluzione con ricorrenza
        }
    }

     /* il valore nell'angolo in alto a destra 
     della matrice dp rappresenta la sottosequenza 
     palindroma di lunghezza massima */
     return dp[0][n - 1]; 
}
}

int main(){

    int t = 0;
    cin>>t;
    
    if(t > 60){  //verifica dei costraints
      cout<<-1<<endl;
      return 0;
    }
    
    while(t--){
        
     string input;
     cin>>input;
     
     cout<<solve(input)<<endl;
        
    }
    return 0;
}
