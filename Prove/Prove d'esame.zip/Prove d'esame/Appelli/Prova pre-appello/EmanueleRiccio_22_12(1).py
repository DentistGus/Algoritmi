
memo = dict()
#dizionario globale

def isPal(s): #funzione per verificare se la stringa è palindroma
    N = len(s)
    if N==0 or N==1:
        return True
    if N==2 and s[0]==s[1]:
        return True
    
    for i in range(N//2):
        if s[i]!=s[N-1-i]:
            return False
    return True

def maxPal(S, N, i, sPal, lPal):#S, N sono fissi, perciò li ometto dalla ricorrenza
    
    #DP[i, sPal, lPal] = max(DP[i+1, sPal+s[i],lPal+1], D[i+1, sPal, lPal])
                         #Decido se prendere o meno un carattere
                      #Problema dello zaino
    #O(N^2)
    key = "%d-%s-%d" % (i, sPal, lPal)
    if key in memo:
        return memo[key]
    
    if i == N:#se ho terminato i caratteri(ho sforato)
        if isPal(sPal): #verifico se è palindroma oppure
            memo[key] = lPal
            return lPal
        else:
            memo[key] = 0
            return 0
        
    memo[key] = max(maxPal(S,N, i+1, sPal+S[i], lPal+1), maxPal(S,N, i+1, sPal, lPal))
    return memo[key]
    
def main():
    T = int(input())
    for t in range(T):
        S = input()
        N = len(S)
        memo.clear() #resetto prima di richiamare maxPal su
        #una nuova stringa
        sol = maxPal(S, N, 0, "", 0)
        print(sol)
    
if __name__=="__main__":
    main()

