SIMONE IZZO M63001320
#include <iostream>
using namespace std;
#include <bits/stdc++.h>
//#define max 100


int solve(string parola){
   int n; 
   int i, j, cl;
   n=parola.length();
   int dp[n][n];
 
    if(n==0){cout<<" stringa vuota "; return 0; }
    else{
  
   
    for(int i = 0 ; i < n ; i++){
        for(int j = 0 ; j < n ; j++){
            if(i==j)dp[i][j]=1;
            else
                dp[i][j]=0;
        }
    }
    
    for (cl=2; cl<=n; cl++)
    {
        for (i=0; i<n-cl+1; i++) 
        {
            j = i+cl-1;
            if (parola[i] == parola[j] && cl == 2) 
               dp[i][j] = 2;
            else if (parola[i] == parola[j])//se le
               dp[i][j] = dp[i+1][j-1] + 2;
            else
               dp[i][j] = max(dp[i][j-1], dp[i+1][j]);
        }
    }
    /*
    for(int i = 0 ; i < n ; i++){
        for(int j = 0 ; j < n ; j++){
            cout<<dp[i][j]<<" ";
        }
        cout<<endl;
    }
 */
    
    return dp[0][n-1];
    }
}
int main() {
	
	int T;
	cin>>T;
	//if(T>60){cout<<"troppi test case, ERRORE"; return 7;}
	while(T--){
	    string parola;
	    cin>>parola;
	    int x;
	    x=solve(parola);
	    
	    cout<<x<<endl;
	    
	}
	return 0;
}
/* La complessità è in via teorica è O(n^2), in realtà è leggermente inferiore in quanto 
T(n)=(n-2)*(n-cl-1)che è approssimabile a T(n)=(n)*(n)-->T(n)=O(n^2)
*/