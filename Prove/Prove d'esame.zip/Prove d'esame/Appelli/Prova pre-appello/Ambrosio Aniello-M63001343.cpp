//
//  Ambrosio Aniello-M63001343.cpp
//  Esame ASD 22/12/21
//
//  Created by Aniello Ambrosio on 22/12/21.
//
//  Ambrosio Aniello-M63001343

#include <iostream>
#include <string>
#include <bits/stdc++.h>
using namespace std;

int solve(string s, string end_s){
    
    int dp[s.length()+1][end_s.length()+1];
            for(int i=1; i<s.length(); i++)
                dp[i][0] = 0;
            for(int j=0; j<end_s.length(); j++)
                dp[0][j] = 0;
                
    for(int i=1; i<=s.length(); i++){
        for(int j=1; j<=end_s.length(); j++){
            if(s[i-1] == end_s[j-1])
                dp[i][j] = dp[i-1][j-1]+1;
            else if(dp[i-1][j] >= dp[i][j-1])
                dp[i][j] = dp[i-1][j];
            else
                dp[i][j] = dp[i][j-1];
        }
    }
    return dp[end_s.length()][s.length()];
}

int main(){
    int t;
    cin>>t;
    cin.ignore();
    while(t--){
        string s, end_s;
        getline(cin,s);
        int count = 1;
        if(s.length()==0 || s.length()==1){
            cout<<s.length()<<endl;
            continue;
        }
        for(int i=0; i<s.length(); i++)
            end_s=s[i]+end_s;
            count=solve(s,end_s);
            cout<<count<<endl;
    }
    return 0;
}

/*
La complessità dell'algoritmo è O(s.lenght()*end_s.lenght()), ovvero le stringhe usate nella memoization.
*/
