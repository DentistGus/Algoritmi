# cook your dish here
# Antonio Avolio M63001352

# Ricerco la più lunga sottostringa in comune tra due stringe
# prendendo in considerazione come seconda stringa la prima stringa
# invertita, così se hanno una sottostringa in comune è un palindromo
# per definizione
def main():
    T = int(input())

    for _ in range(T):
        word = input()
        # Salvo alcune variabili per non doverle calcolare ad ogni iterazione
        reversed_word = word[::-1]
        l = len(word)
        
        pal_table = [ [ 0 for _ in range(l+1) ] for _ in range(l+1) ] # Matrice tutti zeri
        for i in range(l):
            for j in range(l):
                if(word[i] == reversed_word[j]): 
                    pal_table[i+1][j+1] = pal_table[i][j]+1
                else:
                    pal_table[i+1][j+1] = max(pal_table[i+1][j],pal_table[i][j+1])
        print(pal_table[l][l])
        

if __name__ == "__main__":
    main()

# La complessità dell'algoritmo è : O(n^2) (grazie alla memoization)