#Nelli Marisanna
#M63001323
#Complessità: O(n^2) con n lunghezza della stringa

def stringaPalindroma(stringa) :
    n = len(stringa)  

    if n==0:
        return 0
 
    t = [[0 for x in range(n)] for y in range(n)]
    maxLen = 1  #Tutte le stringhe di un carattere sono palindrome
    i = 0
    while (i < n) :
        t[i][i] = True
        i = i + 1

    inizio = 0
    i = 0
    while i < n - 1 :
        if (stringa[i] == stringa[i + 1]) :
            t[i][i + 1] = True
            inizio = i
            maxLen = 2
        i = i + 1

    k = 3 #k indica la lunghezza della sottostringa
    while k <= n :
        i = 0
        while i < (n - k + 1) :
            j = i + k - 1
     
            if (t[i + 1][j - 1] and stringa[i] == stringa[j]) :
                t[i][j] = True
     
                if (k > maxLen) :
                    inizio = i
                    maxLen = k
            i = i + 1
        k = k + 1
 
    return maxLen 
 
 
if __name__ == '__main__':
 
    str1 = "ADAM"
    str2 = "MADAM"

    print(stringaPalindroma(str1))
    print(stringaPalindroma(str2))
