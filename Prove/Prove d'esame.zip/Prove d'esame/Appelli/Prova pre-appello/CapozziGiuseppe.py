#La complessità è O(n^2) poichè il tempo per sottoproblema è pari a O(1) ed il numero di sottoproblemi è pari a O(n^2), dove n è la lunghezza della stringa

def max_length(i:int,j:int, record:list, stringa:list):
    if record[i][j] != -1:
        return record[i][j];
    if i>j:
        return 0
    elif i == j:  
        return 1
    elif i<j and stringa[i]==stringa[j]:
        record[i][j] = 2 + max_length(i+1, j-1, record, stringa)
        return record[i][j]
    elif i<j and stringa[i]!=stringa[j]:
        record[i][j] = max( max_length(i+1,j, record, stringa), max_length(i,j-1, record, stringa) );
        return record[i][j];
    return 0
        


        
        
def main():
    try:
        string = int(input())
        for _ in range(string):
            stringa:str = input().strip()
            if stringa == "" or stringa == " ":
                print(1)
            else:    
                stringa = stringa.lower()
                stringa = list(stringa)
                memo:list = [[-1 for a in range(len(stringa)+2)] for b in range(len(stringa)+2)]
                print(max_length(0,len(stringa)-1, memo, stringa))

    
    except EOFError:
        return
    
    
main()


