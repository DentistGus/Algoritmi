#include <iostream>
#include <string>
#include<vector>
#include <climits>
using namespace std;
#define DBG 1
//O(n), n è la dimensione dell'input
bool check_palindrome(string in,pair<int,int> bounds){
  /*
  //string reverted;
  for(int i=bounds.first;i<=bounds.second;i++){
    cout<<" Confronting "<< in[i]<< in[bounds.second-i]<<endl;
    if(in[bounds.second-i]!=in[i])
      return false;
  }*/
  string reverted;
  string slice;
  for( int i=bounds.second;i>=bounds.first;i--)
    reverted.push_back(in[i]);
  for( int i=bounds.first;i<=bounds.second;i++)
      slice.push_back(in[i]);
  //return true;
  return reverted==slice;
}

//O(n^2)
int longest_palindromic_subsequence(string in,vector< vector <int > > &dp,int idx, int rev_idx){
  if(in.size()==0)
    return 1;
  //cout<<" called for "<< idx << " "<< rev_idx<<endl;
  if(dp[idx][rev_idx]!=-1)
    return dp[idx][rev_idx];
  if(idx==rev_idx) //sono la stessa lettera
    return 1;
  pair<int ,int> h;
  h.first=idx;
  h.second=rev_idx;
  int max=INT_MIN;
  if(check_palindrome(in,h))
    max=rev_idx-idx+1;
  int actual;
  //Altrimenti, per ogni possibile combinazione.
  pair <int ,int> m;
  for( int i=idx;i<in.size();i++){
    for(int j=rev_idx;j>=0;j--){
      m.first=i;
      m.second=j;
      if(m!=h){ // se non sto provando sempre la stessa sequenza
        actual=longest_palindromic_subsequence(in,dp,i,j);
        if(actual>max)
          max=actual;
      }
    }
  }
  dp[idx][rev_idx]=max;
  return dp[idx][rev_idx];
}

int main(){
  unsigned int num_of_tests;
  string in;
  cin>>num_of_tests;
  while(num_of_tests>0){
    cin>>in;
    vector<vector <int > > dp(in.size(),vector<int> (in.size(),-1));
    pair<int,int> h;
    //h.first=1;
    //h.second=3;
    //string n="luau";
    //cout<<check_palindrome(n,h)<<endl;
    cout<<longest_palindromic_subsequence(in,dp,0,in.size()-1)<<endl;
    num_of_tests--;
  }
  return 0;
}
