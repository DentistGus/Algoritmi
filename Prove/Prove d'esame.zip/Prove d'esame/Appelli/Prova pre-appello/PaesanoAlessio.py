
#Ho una stringa, considero due indici: start ed end inizializzati a 0 e len(s)-1.

# DP[start,end] = 	{DP[start+1, end-1] 							se s[start] = s[end]
#					{1+min(DP[start+1,end],DP[start,end-1]) 		se s[start] != s[end]
#					{			0 									se start >= end

#La complessità nel worst case è O(n^2) dove n = len(s)

import numpy as np

def solve(s):
	if(type(s) != str):
		raise ValueError(f"{s} is not a string")
	length = len(s)

	if(length == 0):
		return 0

	memo = -np.ones(shape=(length,length),dtype=int) 

	def DP(start,end):
		if(start >= end):
			return 0
		if (memo[start,end] == -1):
			if(s[start] == s[end]):
				memo[start,end] = DP(start+1,end-1)
			else: 
				memo[start,end] = 1 + min(DP(start+1,end), DP(start,end-1))
		return memo[start,end]

	
	dp = DP(0,len(s)-1)
	return length - dp

def main():
	t = int(input())
	for _ in range(t):
		parola = input()
		print(solve(parola))

if __name__ == '__main__':
	main()
