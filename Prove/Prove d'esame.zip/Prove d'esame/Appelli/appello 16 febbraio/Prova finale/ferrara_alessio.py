def calc(bd,a,sa,b,sb,c,sc,d,sd):
    if(sa == 0 or sb == 0 or sc == 0 or sd == 0):
        return 0
    spesa = (a[sa-1]+b[sb-1]+c[sc-1]+d[sd-1])
    if (bd - spesa) >= 0:
        return spesa
    return max(calc(bd,a,sa-1,b,sb,c,sc,d,sd), calc(bd,a,sa,b,sb-1,c,sc,d,sd),
               calc(bd,a,sa,b,sb,c,sc-1,d,sd), calc(bd,a,sa,b,sb,c,sc,d,sd-1))

a = [8,6,4]
b = [5,10]
c = [1,3,3,7]
d = [50,14,23,8]
budget = 100
sa = len(a)
sb = len(b)
sc = len(c)
sd = len(d)
a.sort()
b.sort()
c.sort()
d.sort()

tot = calc(budget,a,sa,b,sb,c,sc,d,sd)
if tot > 0:
    print(tot)
else:
    print("denaro insufficiente")

## Trascurando l'ordinamento dei vettori, di cui consideriamo sconosciuta la
## complessità, la complessità è nel caso peggiore (cioè quando il budget è insufficiente)
## il prodotto della dimensione degli insiemi presi in considerazione
## (nel primo esempio quindi O(sa*sb*sc*sd))
