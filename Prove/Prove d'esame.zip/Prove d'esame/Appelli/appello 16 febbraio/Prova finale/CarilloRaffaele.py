#Raffaele Carillo - M63001321
#Complessità: O(m_1*m_2...) dove m_i è il numero di prodotti nella classe i-esima



class Solver:
    def __init__(self,classi,b):
        self.classi = classi
        self.b = b
        self.massimo = 0
        self.chosen = [0]*len(classi)
        self.maxConf = [0]*len(classi)

    def solve(self,i):

        if i >= len(self.classi):
            if sum(self.chosen) > self.massimo:
                self.maxConf = self.chosen.copy()
                self.massimo = sum(self.chosen)
            return

        for a in self.classi[i]:
            self.chosen[i] = a
            if sum(self.chosen) > b:
                self.chosen[i] = 0
                continue #Salto tutte le configurazioni che di certo non producono un risultato
            self.solve(i+1)
        

        


#file = open('provafinale.txt','r')
n = int(input())

for _ in range(n):
    b_c = [int(x) for x in input().split()]
    b = b_c[0]
    c = b_c[1]
    classi = []
    m = 0
    for i in range(c):
        classe = [int(x) for x in input().split()]
        m = classe[0]
        prodotti = classe[1:m+1]
        classi.append(prodotti)

    
    chosen = [0]*len(classi)
    max = 0

    s = Solver(classi,b)
    result = s.solve(0)
    if s.massimo == 0:
        print("Denaro insufficiente")
    else:
        print(s.massimo)
        #print(s.maxConf)



